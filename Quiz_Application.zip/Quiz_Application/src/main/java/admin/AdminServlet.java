package admin;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import db.DbConnection;

public class AdminServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        try (Connection conn = DbConnection.getConnection()) {
            if ("addTopic".equals(action)) {
                String topicName = request.getParameter("topicName");
                String query = "INSERT INTO topics (name) VALUES (?)";
                PreparedStatement ps = conn.prepareStatement(query);
                ps.setString(1, topicName);
                ps.executeUpdate();
                response.sendRedirect("adminDashboard.jsp?message=Topic added successfully");

            } else if ("modifyTopic".equals(action)) {
                int topicId = Integer.parseInt(request.getParameter("topicId"));
                String newTopicName = request.getParameter("newTopicName");
                String query = "UPDATE topics SET name = ? WHERE id = ?";
                PreparedStatement ps = conn.prepareStatement(query);
                ps.setString(1, newTopicName);
                ps.setInt(2, topicId);
                ps.executeUpdate();
                response.sendRedirect("adminDashboard.jsp?message=Topic modified successfully");

            } else if ("deleteTopic".equals(action)) {
                int topicId = Integer.parseInt(request.getParameter("topicId"));
                String query = "DELETE FROM topics WHERE id = ?";
                PreparedStatement ps = conn.prepareStatement(query);
                ps.setInt(1, topicId);
                ps.executeUpdate();
                response.sendRedirect("adminDashboard.jsp?message=Topic deleted successfully");

            } else if ("addQuestion".equals(action)) {
                String questionText = request.getParameter("questionText");
                String option1 = request.getParameter("option1");
                String option2 = request.getParameter("option2");
                String option3 = request.getParameter("option3");
                String option4 = request.getParameter("option4");
                String answer = request.getParameter("answer");
                int topicId = Integer.parseInt(request.getParameter("topicId"));

                String query = "INSERT INTO questions (topic_id, question, option1, option2, option3, option4, answer) VALUES (?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement ps = conn.prepareStatement(query);
                ps.setInt(1, topicId);
                ps.setString(2, questionText);
                ps.setString(3, option1);
                ps.setString(4, option2);
                ps.setString(5, option3);
                ps.setString(6, option4);
                ps.setString(7, answer);
                ps.executeUpdate();
                response.sendRedirect("adminDashboard.jsp?message=Question added successfully");

            } else if ("modifyQuestion".equals(action)) {
                int questionId = Integer.parseInt(request.getParameter("questionId"));
                String questionText = request.getParameter("questionText");
                String option1 = request.getParameter("option1");
                String option2 = request.getParameter("option2");
                String option3 = request.getParameter("option3");
                String option4 = request.getParameter("option4");
                String answer = request.getParameter("answer");

                String query = "UPDATE questions SET question = ?, option1 = ?, option2 = ?, option3 = ?, option4 = ?, answer = ? WHERE id = ?";
                PreparedStatement ps = conn.prepareStatement(query);
                ps.setInt(1, questionId);
                ps.setString(2, questionText);
                ps.setString(3, option1);
                ps.setString(4, option2);
                ps.setString(5, option3);
                ps.setString(6, option4);
                ps.setString(7, answer);
                ps.executeUpdate();
                response.sendRedirect("adminDashboard.jsp?message=Question modified successfully");

            } else if ("deleteQuestion".equals(action)) {
                int questionId = Integer.parseInt(request.getParameter("questionId"));
                String query = "DELETE FROM questions WHERE id = ?";
                PreparedStatement ps = conn.prepareStatement(query);
                ps.setInt(1, questionId);
                ps.executeUpdate();
                response.sendRedirect("adminDashboard.jsp?message=Question deleted successfully");

            } else if ("viewStudentResults".equals(action)) {
                String query = "SELECT * from results";
                PreparedStatement ps = conn.prepareStatement(query);
                ResultSet rs = ps.executeQuery();

                request.setAttribute("studentResults", rs);
                request.getRequestDispatcher("viewResults.jsp").forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("adminDashboard.jsp?message=Error occurred");
        }
    }
}

