package student;

import jakarta.servlet.ServletException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;


import java.io.IOException;
import java.sql.*;

import db.DbConnection;


public class AuthServlet extends HttpServlet {
	public static String student=null;
	
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("signup".equals(action)) {
            signup(request, response);
        } else if ("signin".equals(action)) {
            signin(request, response);
        }
    }

    private void signup(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        Connection conn = null;
        PreparedStatement ps = null;
        PreparedStatement ps1 = null;

        try {
            conn = DbConnection.getConnection();
            ps = conn.prepareStatement("INSERT INTO student (username, password) VALUES (?, ?)");
            ps.setString(1, username);
            ps.setString(2, password);
            ps.executeUpdate();
            
            ps1=conn.prepareStatement("insert into results (name,score) values (?,?)");
            ps1.setString(1, username);
            ps1.setInt(2, 0);
            ps1.executeUpdate();
            
            response.sendRedirect("studentDashboard.jsp?msg=Signup successful, please login.");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("signup.jsp?msg=Error in signup.");
        } 
        try {
        	System.out.println("hello");
        	conn = DbConnection.getConnection();
            ps = conn.prepareStatement("INSERT INTO results (username) VALUES (?)");
            ps.setString(1, username);
            ps.executeUpdate();

		} catch (Exception e1) {
			// TODO: handle exception
		}
    }

    private void signin(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        student=username;

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DbConnection.getConnection();
            ps = conn.prepareStatement("SELECT * FROM student WHERE username = ? AND password = ?");
            ps.setString(1, username);
            ps.setString(2, password);
            rs = ps.executeQuery();
            

            if (rs.next()) {
                HttpSession session = request.getSession();
                session.setAttribute("studentId", rs.getInt("student_id"));
                session.setAttribute("username", rs.getString("username"));
                response.sendRedirect("student.jsp");
            } else {
                response.sendRedirect("login.jsp?msg=Invalid username or password.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("studentDashboard.jsp?msg=Error in login.");
        } 
        
    }
}
