package student;



import jakarta.servlet.RequestDispatcher;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.net.URLEncoder;
import java.io.IOException;
import java.sql.*;
import java.util.*;


import db.DbConnection;


public class ExamServlet1 extends HttpServlet {
    int score=0;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("startExam".equals(action)) {
            startExam(request, response);
        } else if ("submitAnswer".equals(action)) {
            submitAnswer(request, response);
        } else if ("finishExam".equals(action)) {
            finishExam(request, response);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("viewCategories".equals(action)) {
            viewCategories(request, response);
        } else if ("startExam".equals(action)) {
            startExam(request, response);
        }
    }

    private void viewCategories(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DbConnection.getConnection();
            ps = conn.prepareStatement("select *  from topics order by topic_id;");
            ps = conn.prepareStatement("SELECT * FROM topics");

            rs = ps.executeQuery();

            List<Map<String, String>> categories = new ArrayList<>();
            while (rs.next()) {
                Map<String, String> category = new HashMap<>();
                category.put("categoryId", String.valueOf(rs.getInt("topic_id")));
                category.put("categoryName", rs.getString("name"));
                categories.add(category);
            }

            request.setAttribute("categories", categories);
            RequestDispatcher dispatcher = request.getRequestDispatcher("categories.jsp");
            dispatcher.forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp?msg=Error loading categories.");
        } 
    }

    private void startExam(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String categoryId = request.getParameter("categoryId");
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DbConnection.getConnection();
            ps = conn.prepareStatement("SELECT * FROM questions WHERE topic_id = ?");
            ps.setString(1, categoryId);
            rs = ps.executeQuery();
                     
            List<Map<String, String>> questions = new ArrayList<>();
            while (rs.next()) {
                Map<String, String> question = new HashMap<>();
                question.put("questionId", String.valueOf(rs.getInt("student_id")));
                question.put("questionText", rs.getString("question"));
                question.put("optionA", rs.getString("option1"));
                question.put("optionB", rs.getString("option2"));
                question.put("optionC", rs.getString("option3"));
                question.put("optionD", rs.getString("option4"));
                questions.add(question);
                String s=rs.getString("option1");

            }

            request.setAttribute("questions", questions);
            request.setAttribute("categoryId", categoryId);
            RequestDispatcher dispatcher = request.getRequestDispatcher("attemptExam.jsp");
            dispatcher.forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp?msg=Error starting the exam.");
        } 
    }

    private void submitAnswer(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String questionId = request.getParameter("questionId");
        String selectedOption = request.getParameter("selectedOption");
        String feedback=null;
        String username = (String) request.getAttribute("username");


        Connection conn = null;
        PreparedStatement ps = null;
        PreparedStatement ps1 = null;
        ResultSet rs = null;

        try {
            conn = DbConnection.getConnection();
            ps = conn.prepareStatement("SELECT answer FROM Questions WHERE student_id = ?");
            ps.setString(1, questionId);
            rs = ps.executeQuery();

            if (rs.next()) {
                String correctOption = rs.getString("answer"); 
                if(correctOption.equalsIgnoreCase(selectedOption)) {
                	 feedback="Correct!";
                	 String studentName = AuthServlet.student;
                	 conn = DbConnection.getConnection();
                     ps1 = conn.prepareStatement("update results set score=score+1 WHERE name= ?");
                     ps1.setString(1, studentName);
                      ps1.executeUpdate();

                	score++;
                }
                else {
                	 feedback = "Incorrect. The correct answer was: " + correctOption;
                }
                request.setAttribute("score", score);
                response.setContentType("text/plain");
                response.getWriter().write(feedback);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().write("Error submitting the answer.");
        } 
    }

    
    private void finishExam(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	String resultMessage,value=null;
    	Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
        	conn = DbConnection.getConnection();
       	 String studentName = AuthServlet.student;
            ps = conn.prepareStatement("SELECT * FROM results WHERE name = ? ");
            ps.setString(1, studentName);
            rs = ps.executeQuery();
                if(rs.next()) {
                    int score = rs.getInt("score");
                     value = String.valueOf(score);;
                     resultMessage = "Exam completed successfully. Your score: " + value ;
System.out.println("hello");
                     }else {
                         resultMessage = "No results found for the student: " + studentName;
                     }
                
                if(resultMessage != null ) {
                    resultMessage = URLEncoder.encode(resultMessage, "UTF-8");
                    HttpSession session = request.getSession();
                    session.setAttribute("score", value);
                    response.sendRedirect("result.jsp?msg=" + resultMessage);
                }

			
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
    }
       /* String resultMessage = FinishExamService.finishExam(request);
System.out.println(resultMessage);
        // Redirect to result page or error page with the result message
        if (resultMessage.contains("Error")) {
            response.sendRedirect("error.jsp?msg=" + resultMessage);
        } else {
            // Redirect to the result page with the success message
            response.sendRedirect("result.jsp?msg=" + resultMessage);
        }
    }*/

}


